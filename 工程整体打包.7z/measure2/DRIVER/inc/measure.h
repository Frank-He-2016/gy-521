#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_usart.h"
#ifndef _MEASURE_H_
#define _MEASURE_H_
#endif

u8 ic_init(void);