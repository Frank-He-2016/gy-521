#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_usart.h"
#ifndef _USART_H_
#define _USART_H_
#endif
void gpio_init(void);
void usart_init(void);